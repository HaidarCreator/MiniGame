// JavaScript for Mini Game Store

document.addEventListener('DOMContentLoaded', () => {
    console.log('Welcome to Mini Game Store!');

    // Scroll to section functionality
    const links = document.querySelectorAll('nav ul li a');

    links.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);

            if (targetSection) {
                targetSection.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Dynamic game cards loading (for future expansion)
    const games = [
        { title: 'Game Title 1', description: 'Exciting action game' },
        { title: 'Game Title 2', description: 'Immersive RPG experience' },
        { title: 'Game Title 3', description: 'Puzzle game for all ages' }
    ];

    const gameList = document.querySelector('.game-list');

    games.forEach(game => {
        const gameCard = document.createElement('div');
        gameCard.classList.add('game-card');

        gameCard.innerHTML = `
            <h3>${game.title}</h3>
            <p>${game.description}</p>
        `;

        gameList.appendChild(gameCard);
    });
});
